#pragma once

struct studentS {
    char* name;
    int score;
};
typedef struct studentS student;
